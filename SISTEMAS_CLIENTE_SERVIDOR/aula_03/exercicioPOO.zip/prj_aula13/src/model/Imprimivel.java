package model;

public interface Imprimivel {
    final char nlin = '\n';
    
    String formatoString();
    void formatoSystemOut();
}
