package model;

public interface Seguranca {
    boolean validar();
}
