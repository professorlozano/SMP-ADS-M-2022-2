package model;

import javax.swing.JOptionPane;

public class Usuario extends Pessoa implements Imprimivel, Seguranca{
    private String nomeUsuario;
    private String senha;

    public Usuario(String nc, int i, String nu, String s) {
        super(nc, i);
        this.setNomeUsuario(nu);
        this.setSenha(s);
        this.validar();
    }

    
    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    @Override
    public String formatoString(){
        String resp = "Nome: " + super.getNomeCompleto() + nlin +
                      "Idade: " + super.getIdade() + nlin +
                      "Usuario: " + this.getNomeUsuario() + nlin +
                      "Senha: " + this.getSenha();
        return resp;
    }
    
    @Override
    public void formatoSystemOut(){
        String resp = "Nome: " + super.getNomeCompleto() + nlin +
                      "Idade: " + super.getIdade() + nlin +
                      "Usuario: " + this.getNomeUsuario() + nlin +
                      "Senha: " + this.getSenha();
        System.out.println(resp);
    }
    
    @Override
    public boolean validar(){
        if(this.senha.equals("") || this.nomeUsuario.equals("")){
            JOptionPane.showMessageDialog(null,"Informe um usuario ou senha valido");
            super.setNomeCompleto("");
            super.setIdade(0);
            this.setNomeUsuario("");
            this.setSenha("");
            return false;
        }
        else
            return true;
    }
}
