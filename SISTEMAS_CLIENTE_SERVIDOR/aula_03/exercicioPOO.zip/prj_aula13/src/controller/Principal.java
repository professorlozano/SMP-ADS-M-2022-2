package controller;

import model.Produto;
import view.TelaUsuario;
import view.TelaProduto;

public class Principal {
    public static void main(String[] args) {
        //new TelaProduto().setVisible(true);
        new TelaUsuario().setVisible(true);
        /*
        Produto p = new Produto("Macarrao", 10);
        p.validar();
        //System.out.println(p.formatoString());
        p.formatoSystemOut();
        */
        /*
        Usuario u =  new Usuario("Luiz",37,"lozano","vip123");
        //u.formatoSystemOut();
        u.validar();
        System.out.println(u.formatoString());
        */
    }
}
